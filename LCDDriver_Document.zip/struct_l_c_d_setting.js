var struct_l_c_d_setting =
[
    [ "curPosColumn", "struct_l_c_d_setting.html#ae8c6341a75398496f7f83b7fc469898d", null ],
    [ "curPosLine", "struct_l_c_d_setting.html#a2dc10a1db82d09845f161c1cf08cac8b", null ],
    [ "followerAmpRatio", "struct_l_c_d_setting.html#a210736e03a932a8e2e770cc179133c1b", null ],
    [ "isBias1By4", "struct_l_c_d_setting.html#a1969ab5e0a8df272814c4307211484e6", null ],
    [ "isBlink", "struct_l_c_d_setting.html#acbc6594636cc7d26c66ec31a24ba1ea9", null ],
    [ "isCursorDisplay", "struct_l_c_d_setting.html#aa24ac6fe9508fc3ad29d44d31a3de21d", null ],
    [ "isDisplayOn", "struct_l_c_d_setting.html#a590dd76154dc086d8513c8ab70719d2c", null ],
    [ "isDisplayToLeft", "struct_l_c_d_setting.html#a2a141ac6baff6cfde05e6f7ff9af7031", null ],
    [ "isFollowerOnOff", "struct_l_c_d_setting.html#a10e912227593f2e3858d75b149313c78", null ],
    [ "isFunc_2LINE", "struct_l_c_d_setting.html#a06db690d23dff8467eb006842642d95f", null ],
    [ "isFunc_8Bit", "struct_l_c_d_setting.html#a800a6dca8a6a58148d44b219235b1dea", null ],
    [ "isFunc_DoubleHeight", "struct_l_c_d_setting.html#a8f2e75fdc43f14dcabebd3f6a9e0b920", null ],
    [ "isFunc_ISMode", "struct_l_c_d_setting.html#a3fb5a06936e97779f2f7fb9cde7afe4e", null ],
    [ "isInSleep", "struct_l_c_d_setting.html#a610b0fe059118cd7e77579b8858028fd", null ],
    [ "isPowerBoost", "struct_l_c_d_setting.html#aa01f663b95301131475d0726bc902914", null ],
    [ "isPowerIconOn", "struct_l_c_d_setting.html#abba6fc55aaed6f952f7af87c01dfab06", null ],
    [ "isUnderLine", "struct_l_c_d_setting.html#ade9a957ff12a7fd93f2b5085700933ab", null ],
    [ "OSCFreq", "struct_l_c_d_setting.html#a7ee0978eeafb7b80cccd3d6c9e7fa563", null ],
    [ "uiContrast", "struct_l_c_d_setting.html#a0a7dbc4894add4d6462d44a886b53540", null ]
];
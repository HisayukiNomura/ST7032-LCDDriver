var struct_l_c_d___c_o_m_m_a_n_d_s_1_1_i_n_t_o_s_c =
[
    [ "BIAS1BY4", "struct_l_c_d___c_o_m_m_a_n_d_s_1_1_i_n_t_o_s_c.html#ab378a2663c69dfb609710208693a0ad7", null ],
    [ "FREQMASK", "struct_l_c_d___c_o_m_m_a_n_d_s_1_1_i_n_t_o_s_c.html#a4925db2be1e29106fa4e19493a831ad4", null ]
];
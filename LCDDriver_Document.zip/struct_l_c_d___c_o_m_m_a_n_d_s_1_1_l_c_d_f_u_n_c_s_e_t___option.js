var struct_l_c_d___c_o_m_m_a_n_d_s_1_1_l_c_d_f_u_n_c_s_e_t___option =
[
    [ "DOUBLEHEIGHT", "struct_l_c_d___c_o_m_m_a_n_d_s_1_1_l_c_d_f_u_n_c_s_e_t___option.html#a5e9cd93591f4848b1b174c4fb2712313", null ],
    [ "DOUBLELINE", "struct_l_c_d___c_o_m_m_a_n_d_s_1_1_l_c_d_f_u_n_c_s_e_t___option.html#abdf7f664562b1e3ec0fd2889a1e45835", null ],
    [ "EIGHTBITMODE", "struct_l_c_d___c_o_m_m_a_n_d_s_1_1_l_c_d_f_u_n_c_s_e_t___option.html#ab50fc87ce9b70046bfa113d3cf6ae330", null ],
    [ "INSTRUCTIONTABLE", "struct_l_c_d___c_o_m_m_a_n_d_s_1_1_l_c_d_f_u_n_c_s_e_t___option.html#a2e5055cf810e309fa403033eec142b4d", null ]
];
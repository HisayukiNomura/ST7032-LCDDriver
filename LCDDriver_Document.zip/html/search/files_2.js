var searchData=
[
  ['readme_2etxt_0',['readme.txt',['../readme_8txt.html',1,'']]]
];

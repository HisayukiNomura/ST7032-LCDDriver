var searchData=
[
  ['on_0',['ON',['../struct_l_c_d___c_o_m_m_a_n_d_s_1_1_f_o_l_l_o_w_e_r.html#a738f75db3ed5768dff13014e4f810349',1,'LCD_COMMANDS::FOLLOWER']]],
  ['oscfreq_1',['OSCFreq',['../struct_l_c_d_setting.html#a7ee0978eeafb7b80cccd3d6c9e7fa563',1,'LCDSetting']]]
];

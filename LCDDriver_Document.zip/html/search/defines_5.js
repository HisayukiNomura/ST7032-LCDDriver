var searchData=
[
  ['max_5fchars_0',['MAX_CHARS',['../i2c_l_c_d_8h.html#a8adbf2b1e0569dded992fee665e86e70',1,'MAX_CHARS:&#160;i2cLCD.h'],['../i2c_l_c_dlocal_8h.html#a8adbf2b1e0569dded992fee665e86e70',1,'MAX_CHARS:&#160;i2cLCDlocal.h']]],
  ['max_5flines_1',['MAX_LINES',['../i2c_l_c_d_8h.html#a07e2b531c72985b064c431c05dfbc5fc',1,'MAX_LINES:&#160;i2cLCD.h'],['../i2c_l_c_dlocal_8h.html#a07e2b531c72985b064c431c05dfbc5fc',1,'MAX_LINES:&#160;i2cLCDlocal.h']]]
];

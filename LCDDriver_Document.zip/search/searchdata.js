var indexSectionsWithContent =
{
  0: "abcdefilmoprsuv　こそソメラ主使変実応概特秋",
  1: "cdefilps",
  2: "ilr",
  3: "ilm",
  4: "abcdefiloprsu",
  5: "acdilm",
  6: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "全て",
  1: "データ構造",
  2: "ファイル",
  3: "関数",
  4: "変数",
  5: "マクロ定義",
  6: "ページ"
};

